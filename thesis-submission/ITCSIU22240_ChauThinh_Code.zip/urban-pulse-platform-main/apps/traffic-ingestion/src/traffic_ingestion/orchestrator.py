"""Orchestrates ingestion jobs across all traffic data sources."""

import json
import logging
import time
from pathlib import Path
from typing import Any

from urbanpulse_core.config import settings
from traffic_ingestion.publishers import Publisher
from traffic_ingestion.sources.vietmap import fetch_route_raw

logger = logging.getLogger(__name__)

_INTER_REQUEST_DELAY_S = 10


def _load_routes() -> list[dict[str, Any]]:
    with open(Path(settings.routes_file)) as f:
        return json.load(f)  # type: ignore[no-any-return]


def run(publisher: Publisher, api_key: str) -> None:
    """Fetch all routes sequentially (10 s delay between calls) and publish each."""
    routes = _load_routes()
    total = len(routes)
    logger.info(
        "Starting crawl cycle: %d routes, %ds inter-request delay",
        total,
        _INTER_REQUEST_DELAY_S,
    )

    for i, route in enumerate(routes):
        try:
            t0 = time.monotonic()
            raw_response, polled_at_ms, timestamp_utc = fetch_route_raw(
                route_id=route["route_id"],
                origin=route["origin"],
                destination=route["destination"],
                origin_anchor=route["origin_anchor"],
                destination_anchor=route["destination_anchor"],
                api_key=api_key,
            )
            latency_api_ms = int((time.monotonic() - t0) * 1000)
            publisher.publish(route["route_id"], polled_at_ms, timestamp_utc, raw_response)
            logger.info(
                "[%d/%d] %s → %s  latency_api_ms=%d",
                i + 1,
                total,
                route["origin"],
                route["destination"],
                latency_api_ms,
            )
        except Exception:
            logger.exception("Failed to fetch route %s", route["route_id"])

        if i < total - 1:
            time.sleep(_INTER_REQUEST_DELAY_S)
