"""Online feature consumer: streams vietmap-raw → Postgres.

Uses the same confluent_kafka pattern as streaming-service (proven, no
compatibility issues). Parses raw VietMap envelopes, computes per-route
rolling stats using Welford's online algorithm and writes to Postgres on
every message, achieving p95 ingestion-to-feature latency < 20 s.
"""

import json
import logging
import signal
import time
from datetime import datetime, timezone

import psycopg2
import psycopg2.extras
from confluent_kafka import Consumer, KafkaError, KafkaException, Message, Producer
from urbanpulse_core.config import settings
from urbanpulse_core.models.traffic import CongestionMetrics, _calc_congestion

from online.baseline import load_baseline, BaselineEntry
from online.models import RouteWindow

logger = logging.getLogger(__name__)

TOPIC = "vietmap-raw"
GROUP_ID = "online-features-group"

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS online_route_features (
    route_id                TEXT             NOT NULL,
    window_start            TIMESTAMPTZ      NOT NULL,
    updated_at              TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
    observation_count       INTEGER          NOT NULL DEFAULT 0,
    mean_duration_minutes   DOUBLE PRECISION,
    stddev_duration_minutes DOUBLE PRECISION,
    last_duration_minutes   DOUBLE PRECISION,
    mean_heavy_ratio        DOUBLE PRECISION,
    last_heavy_ratio        DOUBLE PRECISION,
    duration_zscore         DOUBLE PRECISION,
    is_anomaly              BOOLEAN          NOT NULL DEFAULT FALSE,
    last_ingest_lag_ms      BIGINT,
    heavy_ratio_deviation   DOUBLE PRECISION,
    p95_to_mean_ratio       DOUBLE PRECISION,
    max_severe_segments     DOUBLE PRECISION,
    PRIMARY KEY (route_id, window_start)
);
CREATE INDEX IF NOT EXISTS idx_online_updated_at
    ON online_route_features (updated_at DESC);
-- Migrate existing tables: add columns if they don't exist yet
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS heavy_ratio_deviation  DOUBLE PRECISION;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS p95_to_mean_ratio      DOUBLE PRECISION;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS max_severe_segments    DOUBLE PRECISION;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS mean_moderate_ratio    DOUBLE PRECISION;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS mean_low_ratio         DOUBLE PRECISION;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS geometry               JSONB;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS congestion_segments    JSONB;
ALTER TABLE online_route_features ADD COLUMN IF NOT EXISTS zscore_threshold       DOUBLE PRECISION;
"""

_UPSERT_SQL = """
INSERT INTO online_route_features (
    route_id, window_start, updated_at,
    observation_count,
    mean_duration_minutes, stddev_duration_minutes, last_duration_minutes,
    mean_heavy_ratio, last_heavy_ratio,
    duration_zscore, is_anomaly,
    last_ingest_lag_ms,
    heavy_ratio_deviation, p95_to_mean_ratio, max_severe_segments,
    mean_moderate_ratio, mean_low_ratio,
    geometry, congestion_segments,
    zscore_threshold
) VALUES (
    %(route_id)s, %(window_start)s, NOW(),
    %(observation_count)s,
    %(mean_duration_minutes)s, %(stddev_duration_minutes)s, %(last_duration_minutes)s,
    %(mean_heavy_ratio)s, %(last_heavy_ratio)s,
    %(duration_zscore)s, %(is_anomaly)s,
    %(last_ingest_lag_ms)s,
    %(heavy_ratio_deviation)s, %(p95_to_mean_ratio)s, %(max_severe_segments)s,
    %(mean_moderate_ratio)s, %(mean_low_ratio)s,
    %(geometry)s, %(congestion_segments)s,
    %(zscore_threshold)s
)
ON CONFLICT (route_id, window_start) DO UPDATE SET
    updated_at              = NOW(),
    observation_count       = EXCLUDED.observation_count,
    mean_duration_minutes   = EXCLUDED.mean_duration_minutes,
    stddev_duration_minutes = EXCLUDED.stddev_duration_minutes,
    last_duration_minutes   = EXCLUDED.last_duration_minutes,
    mean_heavy_ratio        = EXCLUDED.mean_heavy_ratio,
    last_heavy_ratio        = EXCLUDED.last_heavy_ratio,
    duration_zscore         = EXCLUDED.duration_zscore,
    is_anomaly              = EXCLUDED.is_anomaly,
    last_ingest_lag_ms      = EXCLUDED.last_ingest_lag_ms,
    heavy_ratio_deviation   = EXCLUDED.heavy_ratio_deviation,
    p95_to_mean_ratio       = EXCLUDED.p95_to_mean_ratio,
    max_severe_segments     = EXCLUDED.max_severe_segments,
    mean_moderate_ratio     = EXCLUDED.mean_moderate_ratio,
    mean_low_ratio          = EXCLUDED.mean_low_ratio,
    geometry                = EXCLUDED.geometry,
    congestion_segments     = EXCLUDED.congestion_segments,
    zscore_threshold        = EXCLUDED.zscore_threshold
"""


def _current_hour_ts() -> int:
    now = datetime.now(timezone.utc)
    return int(now.replace(minute=0, second=0, microsecond=0).timestamp())


class OnlineFeatureProcessor:
    """Stateful processor: maintains per-route windows and writes to Postgres."""

    _BASELINE_TTL = 6 * 3600.0

    def __init__(self, pg_dsn: str) -> None:
        self._pg_dsn = pg_dsn
        self._pg = psycopg2.connect(pg_dsn)
        self._pg.autocommit = True
        self._windows: dict[str, RouteWindow] = {}
        self._baseline: dict[str, BaselineEntry] = {}
        self._last_baseline_refresh: float = 0.0

        with self._pg.cursor() as cur:
            cur.execute(_CREATE_TABLE_SQL)
        logger.info("online-features: Postgres ready, table ensured")

        self._restore_windows()
        self._refresh_baseline()

    def _restore_windows(self) -> None:
        """Restore in-memory RouteWindow state from Postgres for the current hour.

        Reconstructs Welford accumulators from stored mean/stddev/count so
        that a restart mid-hour continues accumulating rather than resetting.
        M2 = stddev² × (count - 1) is the exact inverse of the stddev formula.
        """
        hour_ts = _current_hour_ts()
        window_start = datetime.fromtimestamp(hour_ts, tz=timezone.utc)
        try:
            with self._pg.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """
                    SELECT route_id, observation_count,
                           mean_duration_minutes, stddev_duration_minutes,
                           last_duration_minutes, mean_heavy_ratio, last_heavy_ratio,
                           last_ingest_lag_ms, max_severe_segments
                    FROM online_route_features
                    WHERE window_start = %s
                    """,
                    (window_start,),
                )
                rows = cur.fetchall()
        except Exception as exc:
            logger.warning("online-features: could not restore windows — %s", exc)
            return

        restored = 0
        for row in rows:
            count = row["observation_count"] or 0
            if count == 0:
                continue
            mean = float(row["mean_duration_minutes"] or 0.0)
            stddev = float(row["stddev_duration_minutes"] or 0.0)
            # Reconstruct Welford M2 from stored stddev: M2 = stddev² × (n-1)
            m2 = (stddev ** 2) * max(count - 1, 0)
            mean_heavy = float(row["mean_heavy_ratio"] or 0.0)
            w = RouteWindow(
                window_start_ts=hour_ts,
                count=count,
                mean_duration=mean,
                M2_duration=m2,
                last_duration=float(row["last_duration_minutes"] or 0.0),
                sum_heavy_ratio=mean_heavy * count,
                last_heavy_ratio=float(row["last_heavy_ratio"] or 0.0),
                last_ingest_lag_ms=int(row["last_ingest_lag_ms"] or 0),
                max_severe_segments=float(row["max_severe_segments"] or 0.0),
            )
            self._windows[row["route_id"]] = w
            restored += 1

        logger.info("online-features: restored %d route windows from Postgres", restored)

    def _reconnect(self) -> None:
        """Re-establish Postgres connection after a drop."""
        try:
            self._pg.close()
        except Exception:
            pass
        self._pg = psycopg2.connect(self._pg_dsn)
        self._pg.autocommit = True
        logger.warning("online-features: reconnected to Postgres")

    def _refresh_baseline(self) -> None:
        try:
            self._baseline = load_baseline()
            self._last_baseline_refresh = time.monotonic()
            logger.info("online-features: baseline loaded — %d entries", len(self._baseline))
        except Exception as exc:
            logger.warning("online-features: baseline unavailable — %s", exc)

    def process(self, msg: Message) -> None:
        # Refresh baseline every 6 h
        if time.monotonic() - self._last_baseline_refresh > self._BASELINE_TTL:
            self._refresh_baseline()

        raw_bytes: bytes | None = msg.value()
        if raw_bytes is None:
            return

        # Read metadata from Kafka headers
        route_id = ""
        lag_ms = 0
        for key, val in (msg.headers() or []):  # type: ignore[misc,str-unpack]
            if not isinstance(val, bytes):
                continue
            s = val.decode()
            if key == "route_id":
                route_id = s
            elif key == "ingest_ts":
                try:
                    lag_ms = int(time.time() * 1000) - int(s)
                except (ValueError, TypeError):
                    pass

        if not route_id:
            logger.warning("online-features: message missing route_id header — skipping")
            return

        try:
            api_resp: dict[str, object] = json.loads(raw_bytes)
        except (ValueError, TypeError) as exc:
            logger.warning("online-features: parse error — %s", exc)
            return

        first: dict[str, object] = (api_resp.get("paths") or [{}])[0]  # type: ignore[index]
        duration_ms = float(first.get("time", 0.0))  # type: ignore[arg-type]
        duration_minutes = round(duration_ms / 60000, 1)
        annotations: dict[str, object] = first.get("annotations", {})  # type: ignore[assignment]
        cong_segs: list[dict[str, object]] = annotations.get("congestion", [])  # type: ignore[assignment]
        congestion: CongestionMetrics = _calc_congestion(cong_segs) if cong_segs else CongestionMetrics()

        points_geom: dict[str, object] = first.get("points", {})  # type: ignore[assignment]
        geometry = points_geom.get("coordinates") or None

        # Update or reset hourly window
        hour_ts = _current_hour_ts()
        window = self._windows.get(route_id)
        if window is None or window.window_start_ts != hour_ts:
            window = RouteWindow(window_start_ts=hour_ts)
            self._windows[route_id] = window

        window.update(
            duration_minutes,
            congestion.heavy_ratio,
            congestion.moderate_ratio,
            congestion.low_ratio,
            float(congestion.severe_segments),
            lag_ms,
        )

        # Heavy-ratio z-score vs batch baseline.
        # NOTE: stored as `duration_zscore` in Postgres for historical reasons —
        # the value is the heavy_ratio z-score, not a duration z-score.
        # Threshold is one-sided (high heavy_ratio = congested) and dynamic
        # per-route from the baseline p99 (default 2.0).
        baseline = self._baseline.get(route_id)
        zscore: float | None = None
        is_anomaly = False
        heavy_ratio_deviation: float = window.mean_heavy_ratio
        zscore_threshold: float | None = None
        if baseline and baseline.heavy_ratio_stddev > 0:
            zscore = (window.mean_heavy_ratio - baseline.heavy_ratio_mean) / baseline.heavy_ratio_stddev
            # one-sided: high heavy_ratio is anomalous; low is fine
            is_anomaly = zscore > baseline.zscore_threshold
            heavy_ratio_deviation = window.mean_heavy_ratio - baseline.heavy_ratio_mean
            zscore_threshold = baseline.zscore_threshold

        p95_approx = window.mean_duration + 2.0 * window.stddev_duration
        p95_to_mean_ratio = (p95_approx / window.mean_duration) if window.mean_duration > 0 else 1.0

        window_start = datetime.fromtimestamp(hour_ts, tz=timezone.utc)
        params = {
            "route_id": route_id,
            "window_start": window_start,
            "observation_count": window.count,
            "mean_duration_minutes": window.mean_duration,
            "stddev_duration_minutes": window.stddev_duration,
            "last_duration_minutes": window.last_duration,
            "mean_heavy_ratio": window.mean_heavy_ratio,
            "last_heavy_ratio": window.last_heavy_ratio,
            "duration_zscore": zscore,
            "is_anomaly": is_anomaly,
            "last_ingest_lag_ms": lag_ms,
            "heavy_ratio_deviation": heavy_ratio_deviation,
            "p95_to_mean_ratio": p95_to_mean_ratio,
            "max_severe_segments": window.max_severe_segments,
            "mean_moderate_ratio": window.mean_moderate_ratio,
            "mean_low_ratio": window.mean_low_ratio,
            "geometry": psycopg2.extras.Json(geometry) if geometry is not None else None,
            "congestion_segments": psycopg2.extras.Json(cong_segs) if cong_segs else None,
            "zscore_threshold": zscore_threshold,
        }
        try:
            with self._pg.cursor() as cur:
                cur.execute(_UPSERT_SQL, params)
                cur.execute("NOTIFY route_updated")
        except psycopg2.OperationalError:
            logger.warning("online-features: Postgres connection lost, reconnecting")
            self._reconnect()
            with self._pg.cursor() as cur:
                cur.execute(_UPSERT_SQL, params)
                cur.execute("NOTIFY route_updated")

        logger.info(
            "online-features: route=%s obs=%d zscore=%s lag_ms=%d",
            route_id, window.count,
            f"{zscore:.2f}" if zscore is not None else "N/A",
            lag_ms,
        )

    def close(self) -> None:
        self._pg.close()


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    running = True

    def _shutdown(sig: int, frame: object) -> None:
        nonlocal running
        logger.info("online-features: shutdown signal received")
        running = False

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    processor = OnlineFeatureProcessor(pg_dsn=settings.postgres_dsn)
    dlq_producer = Producer({"bootstrap.servers": settings.kafka_bootstrap_servers})

    consumer = Consumer({
        "bootstrap.servers": settings.kafka_bootstrap_servers,
        "group.id": GROUP_ID,
        "auto.offset.reset": "earliest",  # replay from last committed offset on restart
        "enable.auto.commit": False,
    })
    consumer.subscribe([TOPIC])
    logger.info("online-features: subscribed to %s", TOPIC)

    try:
        while running:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                err = msg.error()
                if err is not None and err.code() == KafkaError._PARTITION_EOF:
                    continue
                raise KafkaException(msg.error())
            processed = False
            try:
                processor.process(msg)
                processed = True
            except Exception as exc:
                logger.warning("online-features: failed to process message, routing to DLQ — %s", exc)
                try:
                    dlq_producer.produce(
                        topic=TOPIC + "-dlq",
                        key=msg.key(),
                        value=msg.value(),
                        headers={"error": str(exc).encode()},
                    )
                    dlq_producer.poll(0)
                except Exception as dlq_err:
                    logger.error("online-features: failed to publish to DLQ — %s", dlq_err)
            if processed:
                try:
                    consumer.commit(asynchronous=False)
                except Exception as commit_err:
                    logger.error("online-features: offset commit failed — %s", commit_err)
    finally:
        dlq_producer.flush()
        consumer.close()
        processor.close()
        logger.info("online-features: stopped cleanly")


if __name__ == "__main__":
    main()
